<template>
I'm the top community component !
</template>
