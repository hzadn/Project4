<template>
    <AdminCommunitiesManager></AdminCommunitiesManager>
</template>

<script>
import AdminCommunitiesManager from '@/components/AdminComponents/AdminCommunitiesManager.vue'
export default {
  data () {
    return {
    }
  },
  components: {
    AdminCommunitiesManager
  }
}
</script>
