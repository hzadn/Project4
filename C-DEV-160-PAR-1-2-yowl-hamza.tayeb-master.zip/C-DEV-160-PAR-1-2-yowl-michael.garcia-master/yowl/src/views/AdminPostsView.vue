<template>
    <AdminPostsManager></AdminPostsManager>
</template>

<script>
import AdminPostsManager from '@/components/AdminComponents/AdminPostsManager.vue'
export default {
  data () {
    return {
    }
  },
  components: {
    AdminPostsManager
  }
}
</script>
