<template>
    <AdminCommentsManager></AdminCommentsManager>
</template>

<script>
import AdminCommentsManager from '@/components/AdminComponents/AdminCommentsManager.vue'
export default {
  data () {
    return {
    }
  },
  components: {
    AdminCommentsManager
  }
}
</script>
