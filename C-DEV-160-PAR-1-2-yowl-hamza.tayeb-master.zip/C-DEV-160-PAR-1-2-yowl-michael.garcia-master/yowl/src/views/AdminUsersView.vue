<template>
    This is from Admin Users View
    <AdminUsersManager></AdminUsersManager>
</template>

<script>
import AdminUsersManager from '@/components/AdminComponents/AdminUsersManager.vue'
export default {
  data () {
    return {
    }
  },
  components: {
    AdminUsersManager
  }
}
</script>

<style>
#firstTable{
  margin-left: auto;
  margin-right: auto;
}
</style>
