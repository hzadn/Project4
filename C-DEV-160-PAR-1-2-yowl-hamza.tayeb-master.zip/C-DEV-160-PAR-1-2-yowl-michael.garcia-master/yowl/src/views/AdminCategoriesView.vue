<template>
    <AdminCategoriesManager></AdminCategoriesManager>
</template>

<script>
import AdminCategoriesManager from '@/components/AdminComponents/AdminCategoriesManager.vue'
export default {
  data () {
    return {
    }
  },
  components: {
    AdminCategoriesManager
  }
}
</script>
